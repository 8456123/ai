# jQuery 库文件存放目录

请将 jquery-3.7.1.min.js 文件放置在此目录下。

文件路径应为：`static/js/jquery-3.7.1.min.js`